/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as access from "../access.js";
import type * as ai from "../ai.js";
import type * as ai_behind from "../ai_behind.js";
import type * as ai_crew from "../ai_crew.js";
import type * as ai_languages from "../ai_languages.js";
import type * as ai_prompts from "../ai_prompts.js";
import type * as ai_self from "../ai_self.js";
import type * as ai_turn from "../ai_turn.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as auth_check from "../auth_check.js";
import type * as backup from "../backup.js";
import type * as briefing from "../briefing.js";
import type * as browser from "../browser.js";
import type * as calendar from "../calendar.js";
import type * as calls from "../calls.js";
import type * as crawl from "../crawl.js";
import type * as crons from "../crons.js";
import type * as device_rule from "../device_rule.js";
import type * as family from "../family.js";
import type * as files from "../files.js";
import type * as guard from "../guard.js";
import type * as http from "../http.js";
import type * as live_boxes from "../live_boxes.js";
import type * as live_data from "../live_data.js";
import type * as livekit from "../livekit.js";
import type * as localRelays from "../localRelays.js";
import type * as memories from "../memories.js";
import type * as messages from "../messages.js";
import type * as people from "../people.js";
import type * as reminders from "../reminders.js";
import type * as sandbox from "../sandbox.js";
import type * as search from "../search.js";
import type * as security from "../security.js";
import type * as self_source from "../self_source.js";
import type * as settings from "../settings.js";
import type * as site from "../site.js";
import type * as speech from "../speech.js";
import type * as sugar from "../sugar.js";
import type * as traces from "../traces.js";
import type * as users from "../users.js";
import type * as voice from "../voice.js";
import type * as workspace from "../workspace.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  access: typeof access;
  ai: typeof ai;
  ai_behind: typeof ai_behind;
  ai_crew: typeof ai_crew;
  ai_languages: typeof ai_languages;
  ai_prompts: typeof ai_prompts;
  ai_self: typeof ai_self;
  ai_turn: typeof ai_turn;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  auth_check: typeof auth_check;
  backup: typeof backup;
  briefing: typeof briefing;
  browser: typeof browser;
  calendar: typeof calendar;
  calls: typeof calls;
  crawl: typeof crawl;
  crons: typeof crons;
  device_rule: typeof device_rule;
  family: typeof family;
  files: typeof files;
  guard: typeof guard;
  http: typeof http;
  live_boxes: typeof live_boxes;
  live_data: typeof live_data;
  livekit: typeof livekit;
  localRelays: typeof localRelays;
  memories: typeof memories;
  messages: typeof messages;
  people: typeof people;
  reminders: typeof reminders;
  sandbox: typeof sandbox;
  search: typeof search;
  security: typeof security;
  self_source: typeof self_source;
  settings: typeof settings;
  site: typeof site;
  speech: typeof speech;
  sugar: typeof sugar;
  traces: typeof traces;
  users: typeof users;
  voice: typeof voice;
  workspace: typeof workspace;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
