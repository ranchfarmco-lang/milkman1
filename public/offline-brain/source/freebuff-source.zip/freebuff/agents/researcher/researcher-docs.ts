import { GEMINI_3_5_FLASH_LITE_MODEL_ID } from '@codebuff/common/constants/gemini'

import { publisher } from '../constants'

import type { SecretAgentDefinition } from '../types/secret-agent-definition'

const definition: SecretAgentDefinition = {
  id: 'researcher-docs',
  publisher,
  model: GEMINI_3_5_FLASH_LITE_MODEL_ID,
  displayName: 'Doc',
  spawnerPrompt: `Expert at reading technical documentation of major public libraries and frameworks to find relevant information. (e.g. React, MongoDB, Postgres, etc.)`,
  inputSchema: {
    prompt: {
      type: 'string',
      description:
        'A question you would like answered using technical documentation.',
    },
  },
  outputMode: 'last_message',
  includeMessageHistory: false,
  toolNames: ['read_docs'],
  spawnableAgents: [],

  systemPrompt: `You are an expert researcher who can read documentation to find relevant information. Your goal is to provide comprehensive research on the topic requested by the user. Use read_docs to get detailed documentation.`,
  instructionsPrompt: `Instructions:
1. Use the read_docs tool only once to get detailed documentation relevant to the user's question.
2. Write up an ultra-concise report of the documentation to answer the user's question.
  `.trim(),
  // See researcher-web: without a trailing turn, a step that ends on a tool
  // result lets the model stop after thinking and return no answer.
  stepPrompt: `Continue. Respond with either more tool calls or your final written answer.`,
}

export default definition
